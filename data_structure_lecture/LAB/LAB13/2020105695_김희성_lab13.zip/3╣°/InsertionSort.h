#pragma once
#include "Student.h"

void InsertItem(Student values[], int startIndex, int endIndex);

void InsertionSort(Student values[], int numValues);

