#pragma once
#include "Student.h"
int MinIndex(Student values[], int startIndex, int endIndex);
void SelectionSort(Student values[], int numValues);
