#pragma once
#include "Student.h"
void BubbleUp(Student values[], int startIndex, int endIndex);
void BubbleSort(Student values[], int numValues);