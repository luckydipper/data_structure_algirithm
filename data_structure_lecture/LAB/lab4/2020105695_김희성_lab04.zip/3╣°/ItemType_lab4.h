// ItemType.h StackDriver
#ifndef lab4_Itemtype_header_2021_10_6
#define lab4_Itemtype_header_2021_10_6

const int MAX_ITEMS = 5;
typedef int ItemType;

#endif // !lab4_Itemtype_header_2021_10_6