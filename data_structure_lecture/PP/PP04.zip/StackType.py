MAX_ITEMS = 100

class StackType:
    def __init__(self):
        self.info = []

    def is_empty(self):
        '''[1]'''
        
    def is_full(self):
        '''[2]'''
        
    def push(self, item):
        '''[3]'''

    def pop(self):
        '''[4]'''

    def top(self):
        '''[5]'''