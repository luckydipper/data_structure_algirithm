MAX_ITEMS = 100

class QueueType():
    def __init__(self):
        self.info = []

    def enqueue(self, data):
        '''[1]'''

    def dequeue(self):
        '''[2]'''

    def is_empty(self):
        '''[3]'''

    def is_full(self):
        '''[4]'''

    def make_empty(self):
        '''[5]'''