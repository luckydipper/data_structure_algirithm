from Factorial import *


if __name__ == '__main__':



    print(f'5! : {factorial(5)}')
    print(f'17! : {factorial(17)}')
    print(f'50! : {factorial(50)}')
