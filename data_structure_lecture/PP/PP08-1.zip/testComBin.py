from ComBin import *


if __name__ == '__main__':


    
    print(f"C(10,3) : {combinations(10, 3)}")
    print(f"C(5,1) : {combinations(5, 1)}")
    print(f"C(45,6) : {combinations(45, 6)}")
   

    
