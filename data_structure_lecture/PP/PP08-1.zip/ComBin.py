def combinations(group, members):
    '''[2]'''
