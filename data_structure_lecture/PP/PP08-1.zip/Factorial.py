def factorial(number):
    '''[3]'''
