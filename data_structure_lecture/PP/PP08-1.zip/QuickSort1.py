def split(values, first, last):
    '''[4]'''

def quick_sort(values, first, last):
    '''[5]'''
