#include <iostream>
#include "exercise_28.h"
#include "exercise_28.cpp"
#include <cstdlib>

typedef char String[9];
struct StudentRecord
{
    String firstName;
    String lastName;
    int id;
    float gpa;
    // char gender;
    int currentHours;
    int totalHours;
};


    //StudentRecord student;
    //StudentRecord students[100];

    //char name9[9] = "aass";
    //String nma3 = "asgd";
    //*(student.firstName) = 'a';
    //*(student.lastName) = 'b';
    //student.id = 1;
    //student.gpa = 1.;
    //student.currentHours = 1;
    //student.totalHours = 3;


    //std::cout << sizeof(student) << std::endl;
    //std::cout << sizeof(students);
    //return 0;
